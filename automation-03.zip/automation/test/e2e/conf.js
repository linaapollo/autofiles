/**
 * Created by webber-ling on 5/18/2017.
 */
"use strict";

const HtmlScreenshotReporter = require('protractor-jasmine2-screenshot-reporter');
const reporter = new HtmlScreenshotReporter({
    cleanDestination: true,
    showSummary: true,
    showConfiguration: true,
    reportTitle: "Protractor / Jasmine Demo Tests Results",
    dest: '../../reports/',
    filename: 'Demo_Report.html',
    ignoreSkippedSpecs: false,
    reportOnlyFailedSpecs: false,
    captureOnlyFailedSpecs: true,
});
const screenshots = require('protractor-take-screenshots-on-demand');
const glob = require("glob");
const fs = require("fs");

exports.config = {
    params: {
        url: {
            url_google: "http://www.google.com",
            url_mercer: "https://colleagueconnect.mmc.com/",
        },

        login: {
            email: 'Webber.Ling@mercer.com',
            user_name: 'mercer/webber-ling',
            password: '********)',
        },

        timeouts: {
            page_timeout: 300000,
            obj_timeout: 30000,
        },
        actionDelay: {
            step_delay: 200,
        },
        userSleep: {
            short: 1000,
            medium: 5000,
            long: 10000,
            long20: 20000,
            long30: 30000,
        },

    },


    /*
     to run a suite use --suite [suite name]
     e.g. protractor conf.js --suite=demo
     without suite defined all specs except those in the [exclude] section will be run
     e.g. protractor conf.js
     */
    specs: ['./features/google_search/debug1.js'],
    suites: {

        google_search: [
            './features/google_search/*.js',
        ],
        sample000: [
            './features/google_search/000_sample_script.js',
        ],
        sample01: [
            './features/google_search/sample_01.js',
        ],
        sample02: [
            './features/google_search/sample_02.js',
        ],
        sample03: [
            './features/google_search/sample_03.js',
        ],
        sample04: [
            './features/google_search/sample_04.js',
        ],
        training01: [
            './features/google_search/training_01.js',
        ],
        training02: [
            './features/google_search/training_02.js',
        ],
        training02_tbl: [
            './features/google_search/training_02_tbl.js',
        ],
        training03: [
            './features/google_search/training_03.js',
        ],
    },
    exclude: [],


    localSeleniumStandaloneOpts: {
        //jvmArgs : ["-Dwebdriver.ie.driver=..\..\driver\IEDriverServer.exe"] // e.g: "node_modules/protractor/node_modules/webdriver-manager/selenium/IEDriverServer_x64_X.XX.X.exe"
    },


    /* time out guide:    https://github.com/angular/protractor/blob/master/docs/timeouts.md*/
    getPageTimeout: 100000, //Timed out waiting for page to load, and alternatively browser.get(address, timeout_in_millis)
    allScriptsTimeout: 100000, // Timed out waiting for asynchronous Angular tasks
    DEFAULT_TIMEOUT_INTERVAL: 50000,


    framework: 'jasmine2',
    // restartBrowserBetweenTests: true,
    //////// directConnect: true,

    seleniumAddress: 'http://localhost:4444/wd/hub',        /// this is for local run
    // sauceUser:  'webber_ling',                           /// this is for saucelab run
    // sauceKey:   '1b1c51e8-b0a3-409b-8434-7b606c3e3430',

    jasmineNodeOpts: {
        showColors: true,
        isVerbose: true,
        includeStackTrace: true,
        defaultTimeoutInterval: 100000, //To change for all specs
                                        //To change for one individual spec, pass a third parameter to  it :  it(description, testFn, timeout_in_millis)
        print: function () {
        }
    },

    // seleniumArgs: ['-Dwebdriver.ie.driver=node_modules/protractor/selenium/IEDriverServer.exe'],
    // 'browserName': 'internet explorer',


    capabilities: {
        // browserName: 'firefox',
        browserName: 'MicrosoftEdge',
        // browserName: 'internet explorer',
            // version:    '11', // ie only
            // 'ignoreProtectedModeSettings': 1,  // ie only
            // "INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS": true,  // ie only
            // 'forceCreateProcessApi': true,  // ie only
        // browserName: 'chrome',
        // platform:   'ANY', //

        acceptSslCerts: true,
        shardTestFiles: false,
        implicit: 30000
    },


    beforeLaunch: function () {
        console.log('======> conf start');

        return new Promise(function (resolve) {
            reporter.beforeLaunch(resolve);
        });

    },
    onPrepare: function () {

        browser.ignoreSynchronization = true;
        // for non-angular application shoudl set browser.ignoreSynchronization = true;
        // see - https://github.com/angular/protractor/blob/master/docs/timeouts.md#waiting-for-angular-on-page-load

        //If you need to navigate to a page which does not use Angular, you can turn off waiting for Angular by setting `browser.waitForAngularEnabled(false).
        //browser.waitForAngularEnabled(false);


        // maxizize browser after it launches
        browser.driver.manage().window().maximize();
        // browser.driver.manage().timeouts().implicitlyWait(300000);
        //
        // // Selenium implicit and page load timeouts
        // browser.manage().timeouts().pageLoadTimeout(300000);
        // browser.manage().timeouts().implicitlyWait(300000);

        // go to site login, can login url from here or from features
        //browser.get('http://juliemr.github.io/protractor-demo/');

        jasmine.getEnv().addReporter(reporter);


        /////////////////////////////////////   below codes are for customized screenshots /////////////////////////
        //joiner between browser name and file name
        screenshots.browserNameJoiner = '_'; //this is the default
        //folder of screenshots
        screenshots.screenShotDirectory = './screenshots';
        // delete any existing screenshots
        glob("./screenshots/*.*", function (err, files) {
            if (err)
                throw err;
            // files.forEach(function (item) {
            //   console.log(item + " found");
            // });
            // Delete files
            files.forEach(function (item) {
                fs.unlink(item, function (err) {
                    if (err)
                        throw err;
                    // console.log(item + " deleted");
                });
            });
        });
        //creates folder of screenshots
        screenshots.createDirectory();
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////   below codes are for clean data>>out /////////////////////////

        // delete any existing output data
        glob("./data/out/*.*", function (err, files) {
            if (err)
                throw err;
            files.forEach(function (item) {
                fs.unlink(item, function (err) {
                    if (err)
                        throw err;
                    // console.log(item + " deleted");
                });
            });
        });
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    },

    afterLaunch: function (exitCode) {
        console.log('======> conf end');
        // browser.close();
        return new Promise(function (resolve) {
            reporter.afterLaunch(resolve.bind(this, exitCode));
        });

    },

};


