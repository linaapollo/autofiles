/**
 * Created by webber-ling on 7/14/2017.
 */
"use strict";
const ec = protractor.ExpectedConditions;
// const fscreenshots = require('protractor-take-screenshots-on-demand');
// const util_windows = require('../common/utilities/util_windows');
// const futil_windows = new util_windows();
const common_obj = require('../common/common_obj');
const fcommon_obj = new common_obj();


const common_page = function () {


  /////////////////////////               page elements            ////////////////////////////////////


  /////////////////////////               page functions            ////////////////////////////////////

};
module.exports = common_page;
