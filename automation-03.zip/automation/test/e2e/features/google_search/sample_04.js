/**
 * Created by webber-ling on 6/12/2018.
 */

//////////////////////////////////////////////////////////////////////////////////
//
//                 use common library & page class
//
//////////////////////////////////////////////////////////////////////////////////

const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();
const google = require('../../page-objects/google.js');
const pgoogle = new google();

describe('Scenario: Sample 3 - Search Protractor - Use Common Library & Page Class', function () {

    it('Step1 - Launch Google', function () {
        browser.get(browser.params.url.url_mercer);

    });

    it('Step2 - Search "Protractor"', function () {
        element(by.css('[name=search-input]')).sendKeys('Webber Ling');
        element(by.css('[id="SerchID"]')).click();
    });

    it('Step3 - Verify expected output displays', function () {

        // fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('a', 'Protractor - end-to-end testing for AngularJS')), 'Search result');
        //
        // element(by.cssContainingText('a', 'Protractor - end-to-end testing for AngularJS')).isDisplayed().then(function(displayed){
        //     if(displayed)
        //         console.log('Expected output displays: ' + displayed);
        //     else
        //         console.log('Expected output does NOT display: ' + displayed);
        // });

        browser.sleep(10000);
    });



});



