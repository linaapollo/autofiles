

/**
 * Created by webber-ling on 6/12/2018.
 */


const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();
const google = require('../../page-objects/google.js');
const pgoogle = new google();


beforeAll(function() {
    console.log('------------ before all');
});
afterAll(function() {
    console.log('------------ after all');
});



describe('Scenario: Training-2: Google Test', function () {

    it('Step1 - Launch Google', function () {

        browser.get(browser.params.url.url_google);

        expect(browser.getCurrentUrl()).toContain('google.com');

    });


    it('Step2 - Search "Protractor"', function () {
        
        element(by.css('[name=q]')).sendKeys('Protractor');
        element(by.css('[value="Google Search"]')).click();

        fcommon_obj.__isElementPresent(element(by.css('[id=ires]')), 'Search Res');

        expect(element(by.css('[id=ires]')).getText()).toContain('Protractor - end-to-end testing for AngularJS');


    });


    it('Step3 - table', function () {
        
        
        element(by.tagName('table')).element(by.tagName('tbody')).all(by.tagName('tr')).then(function(rows){
            
            fcommon_obj.__log('total table rows: ' + rows.length);

            for(let i=0;i<rows.length;i++){
                rows[i].all(by.tagName('td')).get(0).getText().then(function(txt){
                    fcommon_obj.__log('table row: ' + i + ' col: 0 with text: ' + txt)
                });
            }
            
            for(let i=0;i<rows.length;i++){
                rows[i].all(by.tagName('td')).get(0).element(by.tagName('h3')).getText().then(function(txt){
                    fcommon_obj.__log('table row: ' + i + ' col: 0 with text: ' + txt)
                });
            }

        });


        
    });


});





