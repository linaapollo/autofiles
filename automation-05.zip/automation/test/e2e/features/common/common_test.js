/**
 * Created by webber-ling on 7/3/2017.
 */

"use strict";

const ec = protractor.ExpectedConditions;
const dateformat = require('dateformat');
const path = require('path');

const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();
const util_timer = require('../../common/utilities/util_timer');
const futil_timer = new util_timer();
const common_page = require('../../page-objects/common_page');
const pcommon_page = new common_page();
const util_windows = require('../../common/utilities/util_windows');
const futil_windows = new util_windows();



const common_test = function () {

  this.__failStubTest = function (text = 'write test') {
    // this test is designed always to fail - will be used to ensure all test stubs default to failure
    // this is only 1 line of code but it ensures all stub tests fail in the same way
    expect('1').toEqual(text);
  };

  this.__passTestAsNotATest = function (text = 'not a test so always passes') {
    // use this when tests can be passed as the phrase has already been effectively passed earlier in the script
    // this is only 1 line of code but it ensures all such tests pass in the same way

    expect(text).toEqual(text);
  };


  this.__wait4PageReady = function (pagename, element) {

    fcommon_obj.__isElementPresent(element, pagename);
    fcommon_obj.__isElementDisplayed(element, pagename);
    fcommon_obj.__isElementEnabled(element, pagename);

  };

  this.__isStringEqualOrLargerThan = function (expSmall, expBig, bDate = false) {
    if (bDate)
      expect(dateformat(expBig, 'yyyy mm dd')).not.toBeLessThan(dateformat(expSmall, 'yyyy mm dd'));
    else
      expect(expBig.toLowerCase()).not.toBeLessThan(expSmall.toLowerCase());
  };

  this.__isStringLargerThan = function (expSmall, expBig, bDate = false) {
    if (bDate)
      expect(dateformat(expBig, 'yyyy mm dd')).toBeGreaterThan(dateformat(expSmall, 'yyyy mm dd'));
    else
      expect(expBig.toLowerCase()).toBeGreaterThan(expSmall.toLowerCase());
      
  };

  this.__isStringEqualOrLessThan = function (expSmall, expBig, bDate = false) {
    if (bDate)
      expect(dateformat(expBig, 'yyyy mm dd')).not.toBeLessThan(dateformat(expSmall, 'yyyy mm dd'));
    else
      expect(expBig.toLowerCase()).not.toBeLessThan(expSmall.toLowerCase());
  };

  this.__isStringLessThan = function (expSmall, expBig, bDate = false) {
    if (bDate)
      expect(dateformat(expSmall, 'yyyy mm dd')).toBeLessThan(dateformat(expBig, 'yyyy mm dd'));
    else
      expect(expSmall.toLowerCase()).toBeLessThan(expBig.toLowerCase());
  };


  this.__saveDataFile = function (filename) {
    
    let absolutePath_file, absolutePath_exe, actCmd;
    absolutePath_file = path.resolve(__dirname, filename);
    absolutePath_exe = path.resolve(__dirname, '../../common/utilities/SaveDataFile.exe');
    actCmd = '"' + absolutePath_exe + '"' + ' ' + '"' + absolutePath_file + '"';
    futil_windows.__runCmd(actCmd);

  };

};
module.exports = common_test;
