

/**
 * Created by webber-ling on Nov/15/2018.
 */


const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();

const merer_home_demo = require('../../page-objects/mercer_home_demo');
const pmerer_home_demo = new merer_home_demo();



beforeAll(function() {
    console.log('------------ before all');
});
afterAll(function() {
    console.log('------------ after all');
});




describe('Scenario: Training-4: Mercer Home Search', function () {

    it('Step1 - Lauch Mercer Home Page', function () {
        
        browser.get(browser.params.url.url_mercer);
        expect(browser.getCurrentUrl()).toBe('https://colleagueconnect.mmc.com/en-us/Pages/HomePage.aspx');
        
    });

    it('Step1 - Lauch Mercer Home Page', function () {
        
        pmerer_home_demo.__doSearch('Webber Ling');

        browser.sleep(6000);
        
    });

});





