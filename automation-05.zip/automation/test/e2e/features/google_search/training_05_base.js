/**
 * Created by webber-ling on Nov/18/2018.
 */
"use strict";
const path = require('path');

const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();

const util_windows = require('../../common/utilities/util_windows');
const futil_windows = new util_windows();

const common_test = require('../common/common_test');
const fcommon_test = new common_test();

const merer_home_demo = require('../../page-objects/mercer_home_demo');
const pmerer_home_demo = new merer_home_demo();



const traning_05_base = function () {

    this.__doSearch_callScript = function(i, txt){

        describe('Scenario: Training-5: Call AutoIT & Data Driven: ' + i + ' with text: ' + txt, function () {

            it('Step2.4.1 - Do Search - call function - do search - ' + txt, function () {
                
                fcommon_obj.__log('----------------- do search : ' + txt + ' -----------------');
                pmerer_home_demo.__doSearch(txt);
                
            });
        
            it('Step2.4.2 - Do Search - call function - wait for results - ' + txt, function () {
                
                fcommon_obj.__log('----------------- wait for results : ' + txt + ' -----------------');
                fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "' + txt + '"')), 'Search output');
        
            });
        });
    }

};
module.exports = traning_05_base;

