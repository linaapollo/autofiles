

/**
 * Created by webber-ling on Nov/18/2018.
 */

"use strict";

const path = require('path');

const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();

const util_windows = require('../../common/utilities/util_windows');
const futil_windows = new util_windows();

const common_test = require('../common/common_test');
const fcommon_test = new common_test();

const merer_home_demo = require('../../page-objects/mercer_home_demo');
const pmerer_home_demo = new merer_home_demo();

const training_05_base = require('./training_05_base');
const ftraining_05_base = new training_05_base();


beforeAll(function() {
    console.log('------------ before all');
});
afterAll(function() {
    console.log('------------ after all');
});


let _searchAndVerify = function(i, txt){
    
    it('Step2.4.1 - Do Search - call function - do search - ' + i, function () {
        
        fcommon_obj.__log('----------------- do search No. ' + i + ' -----------------');
        pmerer_home_demo.__doSearch(txt);
        
    });

    it('Step2.4.2 - Do Search - call function - wait for results - ' + i, function () {
        
        fcommon_obj.__log('----------------- wait for results No. ' + i + ' -----------------');
        fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "' + txt + '"')), 'Search output');

    });
    
};



describe('Scenario: Training-5: Call AutoIT & Data Driven', function () {



    // it('Step1 - Check file exist before save', function () {

    //     let fileName = 'C:\\Users\\webber-ling\\Desktop\\0MercerOS_Training\\000_SH_Training\\automation\\test\\e2e\\data\\out\\demo.xlsx';
    //     expect(futil_windows.__file_exists(fileName)).toBe(true);
    // });


    // it('Step1.1 - Save file - Local path', function () {
        
    //     let cmd = 'C:\\Users\\webber-ling\\Desktop\\0MercerOS_Training\\000_SH_Training\\automation\\test\\e2e\\common\\utilities\\SaveDataFile.exe';
    //     let fileName = 'C:\\Users\\webber-ling\\Desktop\\0MercerOS_Training\\000_SH_Training\\automation\\test\\e2e\\data\\out\\demo.xlsx';
    //     futil_windows.__runCmd(cmd + ' ' + fileName);

    //     expect(futil_windows.__file_exists(fileName)).toBe(true);
    // });

    // it('Step1.2 - Save file - resolve local path', function () {
        
    //     let cmd = '../../common/utilities/SaveDataFile.exe';
    //     let fileName = '../../data/out/demo.xlsx';
    //     futil_windows.__runCmd(path.resolve(__dirname, cmd) + ' ' + path.resolve(__dirname, fileName));

    //     expect(futil_windows.__file_exists(path.resolve(__dirname, fileName))).toBe(true);
    // });


    // it('Step1.3 - Save file - call function', function () {
        
    //     let fileName = '../../data/out/demo.xlsx';

    //     fcommon_test.__saveDataFile(fileName);

    //     expect(futil_windows.__file_exists(path.resolve(__dirname, fileName))).toBe(true);

        
    // });



    it('Step2 - Lauch Mercer Home Page', function () {
        
        browser.get(browser.params.url.url_mercer);
        expect(browser.getCurrentUrl()).toBe('https://colleagueconnect.mmc.com/en-us/Pages/HomePage.aspx');
        
    });



    // it('Step2.1 - Do Search - inside it', function () {
        
    //     let searchList = ['web', 'webber', 'webber ling'];

    //     for(let i=0;i<searchList.length;i++){

    //         fcommon_obj.__log('----------------- Search No. ' + i + ' -----------------');
    //         pmerer_home_demo.__doSearch(searchList[i]);
    //         fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "' + searchList[i] + '"')), 'Search output');
        
    //     }

    // });


    // let searchList = ['web', 'webber', 'webber ling'];

    // for(let i=0;i<searchList.length;i++){

    //     it('Step2.2 - Do Search - outside it - index: ' + i, function () {
            
    //         fcommon_obj.__log('----------------- Search No. ' + i + ' -----------------');
    //         pmerer_home_demo.__doSearch(searchList[i]);
    //         fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "' + searchList[i] + '"')), 'Search output');
    
    //     });

    // }

    // let searchList = ['web', 'webber', 'webber ling'];
    
    //     for(let i=0;i<searchList.length;i++){
    
    //         it('Step2.3.1 - Do Search - outside it - multiple its - do search - ' + i, function () {
                
    //             fcommon_obj.__log('----------------- do search No. ' + i + ' -----------------');
    //             pmerer_home_demo.__doSearch(searchList[i]);
                
    //         });

    //         it('Step2.3.2 - Do Search - outside it - multiple its - wait for results - ' + i, function () {
                
    //             fcommon_obj.__log('----------------- wait for results No. ' + i + ' -----------------');
    //             fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "' + searchList[i] + '"')), 'Search output');
        
    //         });
    
    //     }
      

    // let searchList = ['web', 'webber', 'webber ling'];
    
    // for(let i=0;i<searchList.length;i++){
    //     _searchAndVerify(i, searchList[i]);
    // }

    let searchList = ['web', 'webber'];

    for(let i=0;i<searchList.length;i++){
        ftraining_05_base.__doSearch_callScript(i, searchList[i])
    }
    

});









