/**
 * Created by webber-ling on Nov/12/2018.
 */
"use strict";
const ec = protractor.ExpectedConditions;
const common_obj = require('../common/common_obj');
const fcommon_obj = new common_obj();



const mercer_home = function () {
    
    
        /////////////////////////               page elements            ////////////////////////////////////
        this._Search_txt = element(by.css('[name=search-input]'));
        this._Search_btn = element(by.css('[id=SerchID]'));

        this._Phone = element(by.css('[id=WorkPhone]'));
    
    
        /////////////////////////               page functions            ////////////////////////////////////
    
        this.__doSearch = function (text) {
            fcommon_obj.__setText('_Search_txt', this._Search_txt, text);
            fcommon_obj.__click('_Search_btn', this._Search_btn);
        };

        this.__returnNames = function(){

            let webbers = [];
            return element.all(by.css('[id=NameFieldLink]')).then(function(all){
                
                for(let i=0;i<all.length;i++){
                    all[i].getText().then(function(txt){
                        webbers[i] = txt;
                    });
                }
                return webbers;
            });
        };

        this.__searchUntilFound = function(list, expectedRes, iCurrentCount=0){

            let self = this;

            if(iCurrentCount<list.length){

                this.__doSearch(list[iCurrentCount]);
                fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "' + list[iCurrentCount] + '"')), 'Search output');

                return element.all(by.css('[id=NameFieldLink]')).first().getText().then(function(txt){
                    if(txt !== expectedRes){
                        fcommon_obj.__log('Recursive in process: ' + iCurrentCount);
                        self.__searchUntilFound(list, expectedRes, iCurrentCount + 1)
                    }
                    else
                        fcommon_obj.__log('Recursive successfully completed at index: ' + iCurrentCount);
                });
            }
            else{
                fcommon_obj.__log('Function: __searchUntilFound failed because reach to the end without match!')
                throw new error('Function: __searchUntilFound failed because reach to the end without match!');
            }

        };
    
    
    };
    module.exports = mercer_home;
