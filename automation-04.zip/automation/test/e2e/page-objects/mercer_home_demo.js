/**
 * Created by webber-ling on Nov/15/2018.
 * this is for protractor jasmine training 04
 */

"use strict";
const ec = protractor.ExpectedConditions;
const common_obj = require('../common/common_obj');
const fcommon_obj = new common_obj();


const mercer_home_demo = function () {


    /////////////////////////               page elements            ////////////////////////////////////
    this._Search_txt = element(by.css('[id=search-input]'));
    this._Search_btn = element(by.css('[id=SerchID]'));


    /////////////////////////               page functions            ////////////////////////////////////

    this.__doSearch = function (text) {
        fcommon_obj.__setText('Search input', this._Search_txt, text);
        fcommon_obj.__click('Search button', this._Search_btn);
    };


};
module.exports = mercer_home_demo;
