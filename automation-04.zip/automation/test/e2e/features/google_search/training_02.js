

/**
 * Created by webber-ling on 6/12/2018.
 */


const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();
const google = require('../../page-objects/google.js');
const pgoogle = new google();


beforeAll(function() {
    console.log('------------ before all');
});
afterAll(function() {
    console.log('------------ after all');
});



describe('Scenario: Training-2: Google Test', function () {

    it('Step1 - Launch Google', function () {

        browser.get(browser.params.url.url_google);

        expect(browser.getCurrentUrl()).toContain('google.com');

    });

    it('Step2 - Search "Protractor"', function () {
        
        element(by.css('[name=q]')).sendKeys('Protractor');
        element(by.css('[value="Google Search"]')).click();

        fcommon_obj.__isElementPresent(element(by.css('[id=ires]')), 'Search Res');

        expect(element(by.css('[id=ires]')).getText()).toContain('Protractor - end-to-end testing for AngularJS');


    });

    it('Step3 - Click "Sign in" to launch signIn dialog', function () {

        element(by.cssContainingText('a', 'Sign in')).click();
        fcommon_obj.__isElementPresent(element(by.css('[aria-label="Email or phone"]')), 'SignIn Dialog');
        expect(element(by.css('[aria-label="Email or phone"]')).isDisplayed()).toBe(true);
        expect(element(by.css('[aria-label="Email or phone"]')).isEnabled()).toBe(true);

        //browser.sleep(2000);

    });

    it('Step4 - GetText, SetText, GetAttribute', function () {


        element(by.css('[class="aCsJod oJeWuf"]')).getText().then(function(txt){
            fcommon_obj.__log(txt);
        });

        pgoogle._SignIn_EmailOrPhone.getAttribute('autocomplete').then(function(txt){
            fcommon_obj.__log('autocomplete: ' + txt);
        });
        pgoogle._SignIn_EmailOrPhone.getAttribute('spellcheck').then(function(txt){
            fcommon_obj.__log('spellcheck: ' + txt);
        });
        pgoogle._SignIn_EmailOrPhone.getAttribute('jsname').then(function(txt){
            fcommon_obj.__log('jsname: ' + txt);
        });
        pgoogle._SignIn_EmailOrPhone.getAttribute('id').then(function(txt){
            fcommon_obj.__log('id: ' + txt);
        });


        pgoogle._SignIn_EmailOrPhone.getAttribute('data-initial-value').then(function(txt){
            fcommon_obj.__log('Before setText: data-initial-value: ' + txt);
        });

        fcommon_obj.__setText('_SignIn_EmailOrPhone', pgoogle._SignIn_EmailOrPhone, 'this is a test')

        pgoogle._SignIn_EmailOrPhone.getAttribute('data-initial-value').then(function(txt){
            fcommon_obj.__log('After setText: data-initial-value: ' + txt);
        });

        //browser.sleep(2000);

    });


    it('Step5 - Regular Expression', function () {


        element(by.css('[class="aCsJod oJeWuf"]')).getText().then(function(txt){
            fcommon_obj.__log('Exact Match: ' + txt);
        });

        element(by.css('[class^="aCsJod"]')).getText().then(function(txt){
            fcommon_obj.__log('Start With: ' + txt);
        });

        element(by.css('[class$="oJeWuf"]')).getText().then(function(txt){
            fcommon_obj.__log('End With: ' + txt);
        });

        element(by.css('[class*="Jod oJe"]')).getText().then(function(txt){
            fcommon_obj.__log('Contains: ' + txt);
        });


    });


    it('Step6 - cssContainingText (tag & class)', function () {


        element(by.cssContainingText('button', 'Forgot email?')).getText().then(function(txt){
            fcommon_obj.__log('cssContainingText - tag: ' + txt);
        });

        element(by.cssContainingText('.ck6P8', 'Forgot email?')).getText().then(function(txt){
            fcommon_obj.__log('cssContainingText - class: ' + txt);
        });


    });

    it('Step7 - byTag, multiple instance', function () {
        
        
        element(by.tagName('h1')).getText().then(function(txt){
            fcommon_obj.__log('tagName h1: ' + txt);
        });

        element(by.tagName('content')).getText().then(function(txt){
            fcommon_obj.__log('tagName content: ' + txt);
        });

        element.all(by.tagName('content')).then(function(all){
            fcommon_obj.__log('total instance of element with tag name <content>: ' + all.length);

            for(let i=0;i<all.length;i++){
                all[i].isDisplayed().then(function(displayed){
                    fcommon_obj.__log('content instance: ' + i + ' displayed: ' + displayed);
                });
            }

            for(let i=0;i<all.length;i++){
                all[i].getText().then(function(txt){
                    fcommon_obj.__log('content instance: ' + i + ' with text: ' + txt);
                });
            }
        });
        

    });
        

    it('Step8 - object hierarchy', function () {
        
        
        element(by.tagName('h1')).all(by.tagName('content')).then(function(all){
            fcommon_obj.__log('total instance of tag <content> under hierarchy: ' + all.length);

            for(let i=0;i<all.length;i++){
                all[i].getText().then(function(txt){
                    fcommon_obj.__log('content instance: ' + i + ' with text: ' + txt);
                });
            }

        });


        
    });


});





