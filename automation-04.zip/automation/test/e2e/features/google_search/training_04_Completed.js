

/**
 * Created by webber-ling on 6/12/2018.
 */


const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();
const mercer_home = require('../../page-objects/mercer_home_completed');
const pmercer_home = new mercer_home();



beforeAll(function() {
    console.log('------------ before all');
});
afterAll(function() {
    console.log('------------ after all');
});




describe('Scenario: Training-4: Mercer Home Search', function () {

    it('Step1 - Lauch Mercer Home Page', function () {
        
        browser.get(browser.params.url.url_mercer);
        expect(browser.getCurrentUrl()).toBe('https://colleagueconnect.mmc.com/en-us/Pages/HomePage.aspx');
        
    });

    // it('Step2 - Search Webber', function () {
        
    //     pmercer_home.__doSearch('Webber Ling');

    //     fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "Webber Ling"')), 'Search output');

    //     // expect(element(by.cssContainingText('div', 'People Results for "Webber Ling"')).isDisplayed()).toBe(true);

    //     browser.sleep(3000);
        
    // });


    // let phone;

    // it('Step3 - Return work phone to be used later', function () {
        
    //     pmercer_home._Phone.getText().then(function(txt){
    //         phone = txt;
    //     });

    //     //fcommon_obj.__log('in same "it" block: ' + phone);  //// does NOT work because it is not a promise

    //     expect(pmercer_home._Phone.getText()).toBe('Phone: +86 (21) 60846579 '); //// work - sample 1

    //     pmercer_home._Search_txt.getAttribute('value').then(function(txt){
    //         fcommon_obj.__log('search field default text: ' + txt);
    //         fcommon_obj.__log('in another promise: ' + phone);  //// work - sample 2
    //     });
        
    // });

    // it('Step3.1 - Use work phone in another it block after value assignment', function () {

    //     fcommon_obj.__log('in another "it" block after value assignment: ' + phone); //// work - sample 3
        
    // });
    
    // let webbers = [];

    // it('Step4 - Return a list of values', function () {

    //     pmercer_home.__doSearch('Webber');
        
    //     fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "Webber"')), 'Search output');

    //     element.all(by.css('[id=NameFieldLink]')).then(function(all){

    //         fcommon_obj.__log('total number of Webber: ' + all.length);
    //         for(let i=0;i<all.length;i++){
    //             all[i].getText().then(function(txt){
    //                 fcommon_obj.__log('Webber: No.' + i + ': ' + txt);
    //                 webbers[i] = txt;
    //             });
    //         }
    //     });
                
    // });

    // it('Step4.1 - Return a list of values', function () {
        
    //     fcommon_obj.__log('in another "it" block after value assignment: ' + webbers); 
                
    // });

    // it('Step4.2 - Return a list of values from function', function () {
        
    //     pmercer_home.__doSearch('Webber');
    //     fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "Webber"')), 'Search output');

    //     //fcommon_obj.__log(pmercer_home.__returnNames()); //// this does NOT work

    //     pmercer_home.__returnNames().then(function(names){
    //         fcommon_obj.__log('return names from function: ' + names); 
    //     });
        
    // });

    // it('Step5 - Filter', function () {
        
    //     pmercer_home.__doSearch('Webber');
        
    //     fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'People Results for "Webber"')), 'Search output');

    //     let WebberLing = element.all(by.css('[id=NameFieldLink]')).filter(function(el){
    //         return el.getText().then(function(txt){
    //             return txt === 'Webber Ling';
    //         });
    //     }).first();

    //     fcommon_obj.__click('WebberLing', WebberLing);
    //     fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('div', 'SUMMARY')), 'Personal page');

    //     browser.sleep(5000);
        
    // });


    // it('Step5 - Recursive', function () {
        
    //     let searchList = ['w', 'we', 'web', 'webb', 'webbe', 'webber', 'webber l'];
    //     pmercer_home.__searchUntilFound(searchList, 'Webber Ling');
        
    // });


});





