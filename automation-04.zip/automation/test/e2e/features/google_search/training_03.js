

/**
 * Created by webber-ling on 6/12/2018.
 */


const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();
const google = require('../../page-objects/google.js');
const pgoogle = new google();

const testData = require('../../data/in/testData.json');
const testData_list = require('../../data/in/testData_list.json');

const util_xlsx = require('../../common/utilities/util_xlsx');
const futil_xlsx = new util_xlsx();
const myXls = './data/in/myExcel.xlsx';

const dateFormat = require('dateformat');

const common_test = require('../common/common_test');
const fcommon_test = new common_test();



beforeAll(function() {
    console.log('------------ before all');
});
afterAll(function() {
    console.log('------------ after all');
});



describe('Scenario: Training-3: Others', function () {

    // it('Step1 - Global Parameters', function () {
        
    //     fcommon_obj.__log(browser.params.url.url_google);
    //     fcommon_obj.__log(browser.params.login.user_name);

    // });

    it('Step2.1 - Keyboard', function () {

        browser.get(browser.params.url.url_google);
        expect(browser.getCurrentUrl()).toContain('google.com');
        pgoogle._SearchInput.sendKeys(protractor.Key.SHIFT, 'a test');
        browser.sleep(3000);
        pgoogle._SearchInput.sendKeys(protractor.Key.CONTROL, 'a');
        browser.sleep(3000);

    });

    // it('Step2.2 - Keyboard (case sensitive) - expect failure', function () {
        
    //     pgoogle._SearchInput.sendKeys(protractor.Key.Shift, 'a test');
    //     browser.sleep(3000);
        
    // });


    // it('Step3.1 - Test Data - non const expect failure: Failed: Assignment to constant variable', function () {
        
    //     fcommon_obj.__log('Step3.1 start --------------------- ');
    //     const a = 'this is a const';
    //     fcommon_obj.__log('a: ' + a);

    //     a = a + ' value changed';
    //     fcommon_obj.__log('a: ' + a);
        
    // });

    //let c = 'can be seen in all it blocks';

    // it('Step3.2 - Test Data - non const', function () {
        
    //     fcommon_obj.__log('Step3.2 start --------------------- ');
    //     let b = 'this is not a const';
    //     fcommon_obj.__log('b: ' + b);

    //     b = b + ' value changed';
    //     fcommon_obj.__log('b: ' + b);
        
    // });

    // it('Step3.3 - Test Data - local variable scope - expect failure: b is not defined ', function () {
        
    //     fcommon_obj.__log('Step3.3 start --------------------- ');
    //     // fcommon_obj.__log('b: ' + b);
    //     fcommon_obj.__log('c: ' + c);
        
    // });

    // it('Step3.4.1 - Test Data - external - json file', function () {
        
    //     fcommon_obj.__log('Step3.4.1 start --------------------- ');
    //     fcommon_obj.__log('Username: ' + testData.Username);
    //     fcommon_obj.__log('BirthDate: ' + testData.BirthDate);
    //     fcommon_obj.__log('Salary: ' + testData.Salary);
    //     fcommon_obj.__log('Retired: ' + testData.Retired);

    // });

    // it('Step3.4.2 - Test Data - external - json file - data type', function () {
        
    //     fcommon_obj.__log('Step3.4.2 start --------------------- ');

    //     if(testData.Salary>999)
    //         fcommon_obj.__log('Salary > 999, number works as Number');

    //     if(testData.Retired)
    //         fcommon_obj.__log('Retired as true, true works as Boolean');

    // });

    // it('Step3.4.3 - Test Data - external - json file - array', function () {
        
    //     fcommon_obj.__log('Step3.4.3 start --------------------- ');

    //     for(let i=0;i<testData_list.length;i++){
    //         fcommon_obj.__log('----------------- User No. ' + i + ' -----------------');
    //         fcommon_obj.__log('Username: ' + testData_list[i].Username);
    //         fcommon_obj.__log('BirthDate: ' + testData_list[i].BirthDate);
    //         fcommon_obj.__log('Salary: ' + testData_list[i].Salary);
    //         fcommon_obj.__log('Retired: ' + testData_list[i].Retired);
    //     }

    // });


    // it('Step3.5.1 - Test Data - external - excel file - read value by column name', function () {
        
    //     fcommon_obj.__log('Step3.5.1 start --------------------- ');
    //     for(let i=1;i<=3;i++){
    //         fcommon_obj.__log('-----------  data row - ready by column name:' + i + '-----------')
    //         fcommon_obj.__log(futil_xlsx.__readCell_iRow_sCol(myXls, 'Sheet1', i, 'Username'));
    //         fcommon_obj.__log(futil_xlsx.__readCell_iRow_sCol(myXls, 'Sheet1', i, 'BirthDate'));
    //         fcommon_obj.__log(futil_xlsx.__readCell_iRow_sCol(myXls, 'Sheet1', i, 'Salary'));
    //         fcommon_obj.__log(futil_xlsx.__readCell_iRow_sCol(myXls, 'Sheet1', i, 'Retired'));
    //     }

    // });

    // it('Step3.5.2 - Test Data - external - excel file - read value by cell name', function () {
        
    //     fcommon_obj.__log('Step3.5.2 start --------------------- ');
    //     for(let i=1;i<=4;i++){
    //         fcommon_obj.__log('-----------  data row - read by cell name:' + i + '-----------')
    //         fcommon_obj.__log(futil_xlsx.__readCell_ByCellName(myXls, 'Sheet1', 'A'+i.toString()));
    //         fcommon_obj.__log(futil_xlsx.__readCell_ByCellName(myXls, 'Sheet1', 'B'+i.toString()));
    //         fcommon_obj.__log(futil_xlsx.__readCell_ByCellName(myXls, 'Sheet1', 'C'+i.toString()));
    //         fcommon_obj.__log(futil_xlsx.__readCell_ByCellName(myXls, 'Sheet1', 'D'+i.toString()));
    //     }

    // });

    // it('Step3.5.3 - Test Data - external - excel file - write cell by cell name', function () {
        
    //     fcommon_obj.__log('Step3.5.3 start --------------------- ');
    //     futil_xlsx.__writeCell_ByCellName(myXls, 'Sheet1', 'A5', 'webber');
    //     futil_xlsx.__writeCell_ByCellName(myXls, 'Sheet1', 'B5', '10/23/1980');
    //     futil_xlsx.__writeCell_ByCellName(myXls, 'Sheet1', 'C5', '5000');
    //     futil_xlsx.__writeCell_ByCellName(myXls, 'Sheet1', 'D5', 'FALSE');

    // });

    // it('Step3.5.4 - Test Data - external - excel file - write cell by iRow sCol', function () {
        
    //     fcommon_obj.__log('Step3.5.4 start --------------------- ');
    //     futil_xlsx.__writeCell_iRow_sCol(myXls, 'Sheet1', 5, 'Username', 'yolanda');
    //     futil_xlsx.__writeCell_iRow_sCol(myXls, 'Sheet1', 5, 'BirthDate', '10/24/1980');
    //     futil_xlsx.__writeCell_iRow_sCol(myXls, 'Sheet1', 5, 'Salary', '6000');
    //     futil_xlsx.__writeCell_iRow_sCol(myXls, 'Sheet1', 5, 'Retired', 'TRUE');
    // });

    // it('Step3.5.5 - Test Data - external - excel file - write cell by iRow iCol', function () {
        
    //     fcommon_obj.__log('Step3.5.5 start --------------------- ');
    //     futil_xlsx.__writeCell_iRow_iCol(myXls, 'Sheet1', 6, 0, 'lori');
    //     futil_xlsx.__writeCell_iRow_iCol(myXls, 'Sheet1', 6, 1, '10/25/1980');
    //     futil_xlsx.__writeCell_iRow_iCol(myXls, 'Sheet1', 6, 2, '7000');
    //     futil_xlsx.__writeCell_iRow_iCol(myXls, 'Sheet1', 6, 3, 'TRUE');
    // });


    // it('Step3.6.1 - Promise - Change our way of coding', function () {
        
    //     fcommon_obj.__log('Step3.6.1 start --------------------- ');
    //     browser.get(browser.params.url.url_google);
    //     expect(browser.getCurrentUrl()).toContain('google.com');

    //     fcommon_obj.__log('before set text'); // 1
    //     fcommon_obj.__setText('_SearchInput', pgoogle._SearchInput, 'test'); // 3
    //     fcommon_obj.__log('after set text' + pgoogle._SearchInput.getAttribute('value')); // 2

    // });

    // it('Step3.6.2 - Promise - Change our way of coding', function () {
        
    //     fcommon_obj.__log('Step3.6.2 start --------------------- ');
    //     browser.get(browser.params.url.url_google);
    //     expect(browser.getCurrentUrl()).toContain('google.com');

    //     fcommon_obj.__log('before set text');
    //     fcommon_obj.__setText('_SearchInput', pgoogle._SearchInput, 'test');
    //     pgoogle._SearchInput.getAttribute('value').then(function(txt){
    //         fcommon_obj.__log('after set text: ' + txt);
    //     });

    // });


    // it('Step3.6.3 - Promise - Change our way of coding - Loop', function () {
        
    //     fcommon_obj.__log('Step3.6.3 start --------------------- ');
    //     browser.get(browser.params.url.url_google);
    //     expect(browser.getCurrentUrl()).toContain('google.com');

    //     fcommon_obj.__setText('_SearchInput', pgoogle._SearchInput, 'Protractor');
    //     fcommon_obj.__click('_SearchButton', pgoogle._SearchButton);
    //     fcommon_obj.__wait4ElementVisible(element(by.css('[id=ires]')), 'Search Res');
    //     expect(element(by.css('[id=ires]')).getText()).toContain('Protractor - end-to-end testing for AngularJS');

    //     // // what we used to do
    //     // fcommon_obj.__log(element.all(by.tagName('h3')).length);

    //     // // for(let i=0;i<element.all(by.tagName('h3')).length;i++){
    //     // //     // do something
    //     // // }


    // //     //// what we shall do in protractor
    //     element.all(by.tagName('h3')).then(function(res){
    //         fcommon_obj.__log('total h3 headers: ' + res.length);

    //         for(let i=0;i<res.length;i++){
    //             res[i].getText().then(function(txt){
    //                 fcommon_obj.__log('res ' + i + ': ' + txt);
    //             });
    //         }

    //     });

    // });

    // it('Step3.7.1 - Comparison - Number', function () {
        
    //     fcommon_obj.__log('Step3.7.1 start --------------------- ');

    //     const a = 1;
    //     const b = 1.1;

    //     expect(a).toBeGreaterThan(b);
    //     expect(a).toBeGreaterThanOrEqual(b);

    //     expect(a).toBeLessThan(b);
    //     expect(a).toBeLessThanOrEqual(b);

    //     expect(a).not.toBeGreaterThan(b);

    // });

    // it('Step3.7.2 - Comparison - String', function () {
        
    //     fcommon_obj.__log('Step3.7.2 start --------------------- ');

    //     const a = 'a';
    //     const b = 'b';

    //     expect(a).toBeGreaterThan(b);
    //     expect(a).toBeGreaterThanOrEqual(b);

    //     expect(a).toBeLessThan(b);
    //     expect(a).toBeLessThanOrEqual(b);

    //     expect(a).not.toBeGreaterThan(b);

    // });


    // it('Step3.8.1 - DateTime', function () {
        
    //     fcommon_obj.__log('Step3.8.1 start --------------------- ');

    //     let now = new Date();

    //     fcommon_obj.__log(now);

    //     fcommon_obj.__log(dateFormat(now, "dddd, mmmm dS, yyyy, h:MM:ss TT"));

    //     fcommon_obj.__log(dateFormat(now, "yyyy/mm/dd"));

    //     fcommon_obj.__log(dateFormat(now, "yy/mmm/d"));

    //     fcommon_obj.__log(dateFormat(now, "mmm/dd/yyyy"));

        
    //     now.setDate(now.getDate()+2);
    //     fcommon_obj.__log(dateFormat(now, "mmm/dd/yyyy"));


    //     fcommon_obj.__log(dateFormat(now, "hh:MM:ss"));


    // });

    // it('Step3.8.2 - DateTime - Compare', function () {
        
    //     fcommon_obj.__log('Step3.8.2 start --------------------- ');

    //     let a = '2018/Oct/9';

    //     let b = '2018/Nov/9';

    //     fcommon_test.__isStringLargerThan(b, a, true);


    // });


    // it('Step3.9 - Deal with special character', function () {
        
    //     fcommon_obj.__log('Step3.9 start --------------------- ');


    //     let a = 'webber\'s trainging';
    //     let b = "webber's trainging";
    //     let c = 'A001\nA002';

    //     fcommon_obj.__log(a);
    //     fcommon_obj.__log(b);
    //     fcommon_obj.__log(c);


    // });


//     it('Step3.9 - throw error', function () {
        
//         fcommon_obj.__log('Step3.9 start --------------------- ');
//         browser.get(browser.params.url.url_google);
//         expect(browser.getCurrentUrl()).toContain('google.com');

//         fcommon_obj.__log('before set text');
//         fcommon_obj.__setText('_SearchInput', pgoogle._SearchInput, 'test');

//         pgoogle._SearchInput.getAttribute('value').then(function(txt){
//             if(txt=='test')
//                 throw new Error('Manully put error here to verify something');
//         });

//     });

});





