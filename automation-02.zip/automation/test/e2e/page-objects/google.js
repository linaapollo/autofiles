/**
 * Created by webber-ling on 6/12/2018.
 */
"use strict";
const ec = protractor.ExpectedConditions;
const common_obj = require('../common/common_obj');
const fcommon_obj = new common_obj();


const google_page = function () {


    /////////////////////////               page elements            ////////////////////////////////////
    this._SearchInput = element(by.css('[name=q]'));
    this._SearchButton = element(by.css('[value="Google Search"]'));
    this._SignIn_EmailOrPhone = element(by.css('[name=identifier]'));


    /////////////////////////               page functions            ////////////////////////////////////

    this.__doSearch = function (text) {
        fcommon_obj.__setText('Search input', this._SearchInput, text);
        fcommon_obj.__click('Search button', this._SearchButton);
    };


};
module.exports = google_page;

