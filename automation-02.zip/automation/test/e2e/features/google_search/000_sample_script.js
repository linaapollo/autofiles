/**
 * Created by webber-ling on 10/23/2017.
 */

const common_test = require('../common/common_test.js');
const fcommon_test = new common_test();


describe('Scenario: 1 - description', function () {

  it('Step1', function () {
    fcommon_test.__failStubTest();
  });

  it('Step2', function () {
    fcommon_test.__failStubTest();
  });

  it('Step3', function () {
    fcommon_test.__failStubTest();
  });

  it('Step4', function () {
    fcommon_test.__failStubTest();
  });

  it('Step5', function () {
    fcommon_test.__failStubTest();
  });

  it('Step6', function () {
    fcommon_test.__failStubTest();
  });

});
