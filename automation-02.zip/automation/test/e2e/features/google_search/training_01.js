

/**
 * Created by webber-ling on 6/12/2018.
 */


const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();



beforeAll(function() {
    console.log('------------ before all');
});
afterAll(function() {
    console.log('------------ after all');
});



describe('Scenario: Training-1: Google Test', function () {

    it('Step1 - Launch Google', function () {

        browser.get(browser.params.url.url_google);

        browser.getCurrentUrl().then(function(currentURL){
            fcommon_obj.__log('Curren URL:' + currentURL);
        });
        
        expect(browser.getCurrentUrl()).toContain('google.com');

    });

    it('Step2 - Search "Protractor"', function () {
        
        element(by.css('[name=q]')).sendKeys('Protractor');
        element(by.css('[value="Google Search"]')).click();

        fcommon_obj.__isElementPresent(element(by.css('[id=ires]')), 'Search Res');

        element(by.css('[id=ires]')).getText().then(function(allText){
            fcommon_obj.__log('Ouput:' + allText);
        });

        expect(element(by.css('[id=ires]')).getText()).toContain('Protractor - end-to-end testing for AngularJS');


    });

    it('Step3 - Click "Sign in" to launch signIn dialog', function () {

        element(by.cssContainingText('a', 'Sign in')).click();
        fcommon_obj.__isElementPresent(element(by.css('[aria-label="Email or phone"]')), 'SignIn Dialog');
        expect(element(by.css('[aria-label="Email or phone"]')).isDisplayed()).toBe(true);
        expect(element(by.css('[aria-label="Email or phone"]')).isEnabled()).toBe(true);
        browser.sleep(2000);

    });



});





