/**
 * Created by webber-ling on 6/12/2018.
 */

//////////////////////////////////////////////////////////////////////////////////
//
//                 use common library
//
//////////////////////////////////////////////////////////////////////////////////

const common_obj = require('../../common/common_obj');
const fcommon_obj = new common_obj();


describe('Scenario: Sample 2 - Search Protractor - Use Common Library', function () {

    it('Step1 - Launch Google', function () {
        browser.get(browser.params.url.url_google);
    });

    it('Step2 - Search "Protractor"', function () {
        //element(by.css('[name=q]')).sendKeys('Protractor');
        fcommon_obj.__setText('Search input', element(by.css('[name=q]')), 'Protractor');

        //element(by.css('[value="Google Search"]')).click();
        fcommon_obj.__click('Search button', element(by.css('[value="Google Search"]')));

        //browser.sleep(3000);
    });

    it('Step3 - Verify expected output displays', function () {

        fcommon_obj.__wait4ElementVisible(element(by.cssContainingText('a', 'Protractor - end-to-end testing for AngularJS')), 'Search result');

        element(by.cssContainingText('a', 'Protractor - end-to-end testing for AngularJS')).isDisplayed().then(function(displayed){
            if(displayed)
                console.log('Expected output displays: ' + displayed);
            else
                console.log('Expected output does NOT display: ' + displayed);
        });

        browser.sleep(3000);
    });



});

