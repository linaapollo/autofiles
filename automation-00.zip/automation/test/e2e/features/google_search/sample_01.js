/**
 * Created by webber-ling on 6/12/2018.
 */

//////////////////////////////////////////////////////////////////////////////////
//
//                 getting started code
//
//////////////////////////////////////////////////////////////////////////////////

describe('Scenario: Sample 1 - Search Protractor', function () {

    it('Step1 - Launch Google', function () {
        browser.get(browser.params.url.url_google);
    });

    it('Step2 - Search "Protractor"', function () {
        element(by.css('[name=q]')).sendKeys('Protractor');
        element(by.css('[value="Google Search"]')).click();
        browser.sleep(3000);
    });

    it('Step3 - Verify expected output displays', function () {

        element(by.cssContainingText('a', 'Protractor - end-to-end testing for AngularJS')).isDisplayed().then(function(displayed){
            if(displayed)
                console.log('Expected output displays: ' + displayed);
            else
                console.log('Expected output does NOT display: ' + displayed);
            expect(displayed).toBe(true);

        });
        browser.sleep(3000);
    });



});

